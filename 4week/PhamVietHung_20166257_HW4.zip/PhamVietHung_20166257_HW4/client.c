/*UDP Echo Client*/
#include <stdio.h>          /* These are the usual header files */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>

#define BUFF_SIZE 1000

int main(int argc, char *argv[]) {
	if (argc!= 3){
		printf("Usage %s <ip> <port_number>\n",argv[0]);
		return 1;
	}

	int sockfd, rcvBytes, sendBytes;
	socklen_t len;
	char buff[BUFF_SIZE+1];
	struct sockaddr_in servaddr;
	//Step 1: Construct socket
	if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
		perror("Error: ");
		return 0;
	}
	//Step 2: Define the address of the server
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr(argv[1]);
	servaddr.sin_port = htons(atoi(argv[2]));

	//Step 3: Communicate with server
	int count;
	len = sizeof(servaddr);
	sendBytes = sendto(sockfd, "Connected\n", strlen("Connected\n"), 0, (struct sockaddr *) &servaddr, len);
	if(sendBytes < 0){
		perror("Error: ");
		return 0;
	}
	rcvBytes = recvfrom(sockfd, buff, BUFF_SIZE, 0, (struct sockaddr *) &servaddr, &len);
	if(rcvBytes < 0){
		perror("Error: ");
		return 0;
	}
	buff[rcvBytes] = '\0';

	if(strcmp(buff, "cliaddr1") == 0) {
		count = 1;
	} else if(strcmp(buff, "cliaddr2") == 0) {
 		count = 2;
 	}

	while(1){
		if(count == 1) {
			memset(buff,'\0',(strlen(buff)+1));
			fgets(buff, BUFF_SIZE, stdin);
			if (buff[0] == '\n') break;

			sendBytes = sendto(sockfd, buff, strlen(buff), 0, (struct sockaddr *) &servaddr, len);
			if(sendBytes < 0){
				perror("Error: ");
				return 0;
			}

		} else if(count == 2) {
			rcvBytes = recvfrom(sockfd, buff, BUFF_SIZE, 0, (struct sockaddr *) &servaddr, &len);
			if(rcvBytes < 0){
				perror("Error: ");
				return 0;
			}
			buff[rcvBytes] = '\0';
			printf("%s\n", buff);
		}
 	}
 	close(sockfd);
  	return 0;
}
