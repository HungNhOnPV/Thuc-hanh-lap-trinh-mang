/*UDP Echo Client*/
#include <stdio.h>          /* These are the usual header files */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>

#define BUFF_SIZE 1000

void output(char buff[BUFF_SIZE]){
    char buff1[BUFF_SIZE];
    char buff2[BUFF_SIZE];
    int i = 0, j = 0, a = 0;
    while (a < strlen(buff)){
    	if ((buff[a] >= 'a' && buff[a] < 'z') || (buff[a] >= 'A' && buff[a] < 'Z')){
                buff1[i] = buff[a];
                i++;
        	} else if (buff[a] >= '0' && buff[a] <= '9') {
        		buff2[j] = buff[a];
        		j++;
        	} else if (buff[a] != ' ' && buff[a] != '\n') {
                  strcpy(buff, "Error\n");
                  return;
            }
        	  a++;
    }

    buff1[i]='\0';
    buff2[j]='\0';

    if (i != 0 && j != 0){
        	buff1[i]='\n';
        	buff1[i+1]='\0';
    }

    strcat(buff1,buff2);
    strcpy(buff,buff1);
    return;
}

int main(int argc, char *argv[]) {
	if (argc!= 2){
        printf("Usage: %s <port_number> \n", argv[0]);
        return 1;
    }

	int sockfd, rcvBytes, sendBytes;
	socklen_t len;
	char buff[BUFF_SIZE+1], buff1[BUFF_SIZE+1];
	struct sockaddr_in servaddr, cliaddr, cliaddr2;

	//Step 1: Construct socket
	if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
		perror("Error: ");
		return 0;
	}

	//Step 2: Bind address to socket
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(atoi(argv[1]));
	if(bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))){
		perror("Error: ");
		return 0;
	}
	printf("Server started");
	printf("%s\n", "..." );

	//Step 3: Communicate with client
	int count = 0;

	for ( ; ; ) {
		len = sizeof(cliaddr);
		rcvBytes = recvfrom(sockfd, buff, BUFF_SIZE, 0, (struct sockaddr *) &cliaddr, &len);
		if(rcvBytes < 0){
			perror("Error: ");
			return 0;
		}
		buff[rcvBytes] = '\0';

		if(count == 0) {
			printf("[%s:%d]: %s", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), buff);
			sendBytes = sendto(sockfd, "cliaddr1", strlen("cliaddr1"), 0, (struct sockaddr *) &cliaddr, len);
			if(sendBytes < 0){
				perror("Error: ");
				return 0;
			}
		} else if(count == 1){
			printf("[%s:%d]: %s", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), buff);
			cliaddr2 = cliaddr;
			sendBytes = sendto(sockfd, "cliaddr2", strlen("cliaddr2"), 0, (struct sockaddr *) &cliaddr, len);
			if(sendBytes < 0){
				perror("Error: ");
				return 0;
			}
		} else {
			printf("Client to send server: %s", buff);
			output(buff);
			sendBytes = sendto(sockfd, buff, rcvBytes, 0, (struct sockaddr *) &cliaddr2, len);
			if(sendBytes < 0){
				perror("Error: ");
				return 0;
			}
		}
		count++;
		// memset(buff,'\0',(strlen(buff)+1));
		// fgets(buff1, BUFF_SIZE, stdin);
		// if (buff1[0] == '\n') break;
	}

	close(sockfd);
	return 0;
}