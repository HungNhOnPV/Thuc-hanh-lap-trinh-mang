#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include "readFile.h"

#define BUFF_SIZE 8192

void menu(){
	printf("MENU\n-----------------------------------\n1. Gửi xâu bất kỳ\n2. Gửi nội dung một file\n");
}

int main(int argc, char* argv[]){
	if (argc!= 3){
		printf("Usage %s <ip> <port_number>\n",argv[0]);
		return 1;
	}

	int client_sock;
	char buff[BUFF_SIZE];
	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;

	//Step 1: Construct socket
	client_sock = socket(AF_INET,SOCK_STREAM,0);

	//Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(atoi(argv[2]));
	server_addr.sin_addr.s_addr = inet_addr(argv[1]);

	//Step 3: Request to connect server
	if(connect(client_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) < 0){
		printf("\nError!Can not connect to sever! Client exit imediately! ");
		return 0;
	}

	int i, j = 0;
	do {
		menu();
		printf("Nhap so: ");
		scanf("%d", &i);

		switch(i) {
			case 1: {
				//Step 4: Communicate with server
				while(1){
					//send message
					memset(buff,'\0',(strlen(buff)+1));
					fgets(buff, BUFF_SIZE, stdin);
					if(strcmp(buff, "\n") == 0 && j == 0) continue;
					msg_len = strlen(buff);
					if (buff[0] == '\n') break;

					bytes_sent = send(client_sock, buff, msg_len, 0);
					if(bytes_sent <= 0){
						printf("\nConnection closed!\n");
						break;
					}

					//receive echo reply
					bytes_received = recv(client_sock, buff, BUFF_SIZE, 0);
					if(bytes_received <= 0){
						printf("\nError!Cannot receive data from sever!\n");
						break;
					}

					buff[bytes_received] = '\0';
					printf("%s\n", buff);
					j++;
				}

				//Step 4: Close socket
				close(client_sock);
				return 0;
			}
			case 2: {
				//Step 4: Communicate with server
				while(1){
					//send message
					memset(buff,'\0',(strlen(buff)+1));
					fgets(buff, BUFF_SIZE, stdin);
					if(strcmp(buff, "\n") == 0 && j == 0) continue;
					if (buff[0] == '\n') break;
					// printf("%s---\n", run(buff));
					strcpy(buff, run(buff));
					msg_len = strlen(buff);

					bytes_sent = send(client_sock, buff, msg_len, 0);
					if(bytes_sent <= 0){
						printf("\nConnection closed!\n");
						break;
					}

					//receive echo reply
					bytes_received = recv(client_sock, buff, BUFF_SIZE, 0);
					if(bytes_received <= 0){
						printf("\nError!Cannot receive data from sever!\n");
						break;
					}

					buff[bytes_received] = '\0';
					printf("%s\n", buff);
					j++;
				}

				//Step 4: Close socket
				close(client_sock);
				return 0;
			}
		}
	}while(i == 1 || i == 2);
}
