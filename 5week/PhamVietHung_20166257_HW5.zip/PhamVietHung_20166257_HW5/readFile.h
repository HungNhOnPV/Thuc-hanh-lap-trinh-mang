#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void readFile(FILE *f, char* A) {
	while(!feof(f)) {
		fscanf(f, "%s", A);
	}
}

void print(char* A) {
	printf("%s\n", A);
}

char* run(char* name) {
	FILE *f;
	char* A, * B;
	A = (char*)malloc(sizeof(char));
	B = (char*)malloc(sizeof(char));

	// printf("%ld\n", strlen(name));

	for(int i = 0; i < strlen(name) -1; i++) {
		B[i] = name[i];
	}

	if((f = fopen(B,"r")) == NULL) {
		printf("Can't open file %s\n", B);
		return B;
	}

	readFile(f, A);

	return A;
}

// int main() {
// 	char* A = run("text.txtt");
// 	printf("%s\n", A);
// 	return 0;
// }